function Light(){
    light = document.getElementById("light");
    document.body.style.backgroundColor = "rgb(255, 255, 255)";
    document.body.style.color = "black";
}

function Dark(){
    document.body.style.backgroundColor = "rgb(47, 49, 54)";
    document.body.style.color = "black";
}


function LangHu(){
    document.getElementById("hu");
    window.location.href = "index-hu.html";
}

function LangEn(){
    document.getElementById("en");
    window.location.href = "index-en.html";
}
